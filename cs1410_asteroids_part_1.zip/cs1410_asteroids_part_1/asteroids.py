from ship import Ship
from rock import Rock

class Asteroids(Ship,Rock):
    def __init__(self,world_width,world_height):
        self.mWorldWidth = world_width
        self.mWorldHeight = world_height
        self.mShip = Ship(world_width/2,world_height/2,world_width, world_height)
        self.mRocks = [Rock(0,0,world_width, world_height) for rock in range(10)]
        self.mObjects = [self.mShip, self.mRocks[0], self.mRocks[1], self.mRocks[2], self.mRocks[3], self.mRocks[4], self.mRocks[5], self.mRocks[6], self.mRocks[7], self.mRocks[8], self.mRocks[9]]
        
    def getWorldWidth(self):
        return self.mWorldWidth
    
    def getWorldHeight(self):
        return self.mWorldHeight
    
    def getShip(self):
        return self.mShip
    
    def getRocks(self):
        return self.mRocks
    
    def getObjects(self):
        return self.mObjects
    
    def turnShipLeft(self,delta_rotation):
        self.mShip.rotate(-delta_rotation)
    
    def turnShipRight(self,delta_rotation):
        self.mShip.rotate(delta_rotation)
    
    def accelerateShip(self,delta_velocity):
        self.mShip.accelerate(delta_velocity)
    
    def evolve(self,dt):
        for obj in self.mObjects:
            obj.evolve(dt)
    
    def draw(self,surface):
        surface.fill((0,0,0))
        for obj in self.mObjects:
            obj.draw(surface)