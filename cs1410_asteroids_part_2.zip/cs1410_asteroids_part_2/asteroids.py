from ship import Ship
from rock import Rock
from bullet import Bullet
from star import Star
import random

class Asteroids(Ship,Rock):
    def __init__(self,world_width,world_height):
        self.mWorldWidth = world_width
        self.mWorldHeight = world_height
        self.mShip = Ship(world_width/2,world_height/2,world_width, world_height)
        self.mRocks = [Rock(0,0,world_width, world_height) for rock in range(10)]
        self.mBullets = []
        self.mStars = [Star(random.uniform(0,world_width), random.uniform(0,world_height), world_width, world_height) for star in range(20)]
        self.mObjects = [self.mShip, self.mRocks[0], self.mRocks[1], self.mRocks[2], self.mRocks[3], self.mRocks[4], self.mRocks[5], 
                         self.mRocks[6], self.mRocks[7], self.mRocks[8], self.mRocks[9], self.mStars[0], self.mStars[1], self.mStars[2], 
                         self.mStars[3], self.mStars[4], self.mStars[5], self.mStars[6], self.mStars[7], self.mStars[8], self.mStars[9], 
                         self.mStars[10], self.mStars[11], self.mStars[12], self.mStars[13], self.mStars[14], self.mStars[15], 
                         self.mStars[16], self.mStars[17], self.mStars[18], self.mStars[19]]
        
    def getWorldWidth(self):
        return self.mWorldWidth
    
    def getWorldHeight(self):
        return self.mWorldHeight
    
    def getShip(self):
        return self.mShip
    
    def getRocks(self):
        return self.mRocks
    
    def getStars(self):
        return self.mStars
    
    def getBullets(self):
        return self.mBullets
    
    def getObjects(self):
        return self.mObjects
    
    def turnShipLeft(self,delta_rotation):
        self.mShip.rotate(-delta_rotation)
    
    def turnShipRight(self,delta_rotation):
        self.mShip.rotate(delta_rotation)
    
    def accelerateShip(self,delta_velocity):
        self.mShip.accelerate(delta_velocity)
        
    def fire(self):
        bullet = self.mShip.fire()
        if len(self.mBullets)<3:
            self.mBullets.append(bullet)
            self.mObjects.append(bullet)
    
    def collideShipAndBullets(self):
        if self.mShip.getActive() == True:
            for b in self.mBullets:
                if b.hits(self.mShip):
                    self.mShip.setActive(False)
                    b.setActive(False)
                    return
                
    def collideShipAndRocks(self):
        if self.mShip.getActive() == True:
            for r in self.mRocks:
                if r.hits(self.mShip):
                    self.mShip.setActive(False)
                    r.setActive(False)
                    return
        
    def collideRocksAndBullets(self):
        for b in self.mBullets:
            for r in self.mRocks:
                if b.hits(r):
                    b.setActive(False)
                    r.setActive(False)
                    return
        
    def removeInactiveObjects(self):
        tmp = []
        for obj in self.mObjects:
            if obj.getActive() == True:
                tmp.append(obj)
        self.mObjects = tmp
        
    def evolveAllObjects(self,dt):
        for obj in self.mObjects:
            obj.evolve(dt)
    
    def evolve(self,dt):
        self.removeInactiveObjects()
        self.evolveAllObjects(dt)
        
    
    def draw(self,surface):
        surface.fill((0,0,0))
        for obj in self.mObjects:
            obj.draw(surface)
            